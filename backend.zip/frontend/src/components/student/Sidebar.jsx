import { useEffect, useState } from "react";

const Sidebar = ({ addOrUpdateStudent, editIndex, students }) => {
  const [data, setData] = useState({
    name: "",
    className: "",
    dob: "",
    email: "",
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (editIndex !== null) {
      setData(students[editIndex]);
    }
  }, [editIndex, students]);

  const validate = () => {
    let e = {};
    if (!data.name) e.name = "Name is required";
    if (!data.className) e.className = "Class is required";
    if (!data.dob) e.dob = "DOB is required";
    if (!data.email.includes("@")) e.email = "Valid email required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    addOrUpdateStudent(data);
    setData({ name: "", className: "", dob: "", email: "" });
    setErrors({});
  };

  return (
    <div className="card">
      <h3 className="text-xl font-bold mb-4">
        {editIndex !== null ? "Edit Student" : "Add Student"}
      </h3>

      <form onSubmit={submit} className="space-y-3">
        <input className="input" placeholder="Student Name"
          value={data.name}
          onChange={(e) => setData({ ...data, name: e.target.value })}
        />
        {errors.name && <p className="error">{errors.name}</p>}

        <input className="input" placeholder="Class"
          value={data.className}
          onChange={(e) => setData({ ...data, className: e.target.value })}
        />
        {errors.className && <p className="error">{errors.className}</p>}

        <input type="date" className="input"
          value={data.dob}
          onChange={(e) => setData({ ...data, dob: e.target.value })}
        />
        {errors.dob && <p className="error">{errors.dob}</p>}

        <input className="input" placeholder="Email"
          value={data.email}
          onChange={(e) => setData({ ...data, email: e.target.value })}
        />
        {errors.email && <p className="error">{errors.email}</p>}

        <button className="btn w-full">
          {editIndex !== null ? "Update Student" : "Add Student"}
        </button>
      </form>
    </div>
  );
};

export default Sidebar;