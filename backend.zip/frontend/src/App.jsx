import React, { useState } from "react";

import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";

import Sidebar from "./components/student/Sidebar";
import StudentTable from "./components/student/StudentTable";

import Hero from "./sections/Hero";
import Academics from "./sections/Academics";
import Features from "./sections/Features";
import Activities from "./sections/Activities";
import Sports from "./sections/Sports";
import About from "./sections/About";
import Contact from "./sections/Contact";

const App = () => {

  const [students, setStudents] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  const addOrUpdateStudent = (student) => {
    if (editIndex !== null) {
      const updated = [...students];
      updated[editIndex] = student;
      setStudents(updated);
      setEditIndex(null);
    } else {
      setStudents([...students, student]);
    }
  };

  const deleteStudent = (index) => {
    setStudents(students.filter((_, i) => i !== index));
  };

  const editStudent = (index) => {
    setEditIndex(index);
  };

  return (
    <div className="pt-10">

      <Navbar />

      {/* WEBSITE SECTIONS */}
      <Hero />
      <Academics />
      <Features />
      <Activities />
      <Sports />

      {/* STUDENT MANAGEMENT */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-8">

          <Sidebar
            addOrUpdateStudent={addOrUpdateStudent}
            editIndex={editIndex}
            students={students}
          />

          <div className="md:col-span-2">
            <StudentTable
              students={students}
              onDelete={deleteStudent}
              onEdit={editStudent}
            />
          </div>

        </div>
      </section>

      <About />
      <Contact />

      <Footer />

    </div>
  );
};

export default App;