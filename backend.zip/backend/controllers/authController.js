const User = require("../models/User");
const generateOTP = require("../utils/generateOTP");

exports.sendOTP = async(req,res)=>{
 try{

  const {phone} = req.body;

  const otp = generateOTP();

  let user = await User.findOne({phone});

  if(!user){
   user = new User({phone,otp});
  }else{
   user.otp = otp;
  }

  await user.save();

  console.log("OTP:", otp);

  res.json({
   success:true,
   message:"OTP sent"
  });

 }catch(err){
  res.status(500).json(err);
 }
};


exports.verifyOTP = async(req,res)=>{
 try{

  const {phone,otp} = req.body;

  const user = await User.findOne({phone});

  if(!user || user.otp !== otp){
   return res.status(400).json({
    message:"Invalid OTP"
   });
  }

  user.isVerified = true;

  await user.save();

  res.json({
   success:true,
   message:"Login successful"
  });

 }catch(err){
  res.status(500).json(err);
 }
};